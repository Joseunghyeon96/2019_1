﻿// Screen.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

/*
1~15번까지 구현했습니다.
적을 죽인 총알은 상대를 관통해서 다음적까지 맞는 기능 추가했습니다.
공격시 공격상태가 표시되나 너무 짧게 표시된다고 생각하여
아래에 상태창을 한개 더만들어서 플레이어가 적의 독공격 범위에 들어오면 
posion! 이라는 글을 보여주고 
적의 독공격 쿨타임이 돌고 독공격이 시작되면 독공격 on 이라는 글을 보여주게 설정해놨습니다.
*/


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <conio.h>
#include <Windows.h>


using namespace std;

void draw(char* loc, const char* face)
{
	strncpy(loc, face, strlen(face));
}
void gotoxy(int x, int y)
{
	COORD pos = { x,y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}


class Screen {
	int size;
	char* screen;

public:
	Screen(int sz) : size(sz), screen(new char[sz + 1]) {}
	~Screen() { delete[] screen; }

	void draw(int pos, const char* face)
	{
		if (face == nullptr) return;
		if (pos < 0 || pos >= size) return;
		strncpy(&screen[pos], face, strlen(face));
	}

	void render()
	{
		printf("%s\r", screen);
	}

	void clear()
	{
		memset(screen, ' ', size);
		screen[size] = '\0';
	}

	int length()
	{
		return size;
	}

};

class GameObject {
protected:
	int pos;
	int life;
	char face[20];
	Screen* screen;
	bool rightMode;

public:
	GameObject()
	{}
	GameObject(int pos, int life, const char* face, Screen* screen)
		: pos(pos), life(life), screen(screen)
	{
		strcpy(this->face, face);
	}

	GameObject(int pos, int life, const char* face, Screen* screen, bool leftMode, bool rightMode)
		:pos(pos), life(life), screen(screen), rightMode(true)
	{
		strcpy(this->face, face);
	}

	void setLife(int life)
	{
		this->life=life;
	}
	int getPosition()
	{
		return pos;
	}
	int getLife()
	{
		return life;
	}
	void setPosition(int pos)
	{
		this->pos = pos;
	}
	void draw()
	{
		screen->draw(pos, face);
	}
	void left()
	{
		rightMode = false;
	}
	void right()
	{
		rightMode = true;
	}
	void lifeDown()
	{
		life--;
	}
	int faceSize()
	{
		return strlen(face);
	}
	bool getMode()
	{
		return rightMode;
	}
};

class Player : public GameObject {
	char rightFace[20];
	char poison[8]={ NULL } ;
	bool hit;
	int playTime;
	int hitTime;
	int poisonCoolTime;
	int poisonTime;

public:
	Player(int pos, int life, const char* face, Screen* screen, const char* rightFace)
		: GameObject(pos, life, face, screen), playTime(0), hitTime(0), poisonCoolTime(0)
		, poisonTime(45), hit(false)
	{
		strcpy(this->rightFace, rightFace);
	}

	void draw()
	{
		if (getMode() == false)
			screen->draw(pos, rightFace);
		else
			screen->draw(pos, face);
	}
	void setLife(int enemyPos)
	{
		if (poisonCoolTime == 0) {
			if (pos > enemyPos - 10 && pos < enemyPos + 10) {
				hitTime++;		
				strcpy(poison, "poison!");
			}
			else {
				hitTime = 0;
				strcpy(poison, "       " );
			}

			if (hitTime > 14)
			{
				lifeDown();
				lifeDown();
				hitTime = 0;
			}
		}
	}
	void hitPoison()
	{
		if(poisonTime>0)
		poisonTime--;
		if (poisonTime == 0)
		{
			strcpy(poison, "       ");
			poisonCoolTime = 30;
			hit = false;
		}
	}
	void moveLeft()
	{
		left();
		setPosition(getPosition() - 1);
	}

	void moveRight()
	{
		right();
		setPosition(getPosition() + 1);
	}
	void hitRange(int enemyPos)
	{
		if (pos > enemyPos - 10 && pos < enemyPos + 10&& poisonCoolTime == 0)
			hit = true;
	}
	int getLife()
	{
		return life;
	}
	int getPlayTime()
	{
		return playTime / 15;
	}
	void update(int enemyPos,int screenSize,int faceSize)
	{
		rePosition(screenSize, faceSize);
		playTime++;
		setLife(enemyPos);
		hitRange(enemyPos);
		if (poisonCoolTime > 0) {
			poisonCoolTime--;
			if(poisonCoolTime==1)
			poisonTime = 45;
		}
		else if(hit==true&&poisonCoolTime==0)
			hitPoison();
		
	}
	void rePosition(int screenSize,int faceSize)
	{
		if (pos<0 && pos>-6)
			pos = screenSize - faceSize;
		else if ((pos + faceSize) > screenSize)
			pos = 0;
	}
	char* getPoison()
	{
		return poison;
	}
	int getPoisonTime()
	{
		return poisonTime;
	}
	const char* poisonMode()
	{
		if (hit)
			return "on!";

		else
			return "off!";
	}
	int getPoisonCoolTime()
	{
		return poisonCoolTime;
	}

};

class Enemy : public GameObject {

	bool resurrection;
	int speed;
public:
	Enemy(int pos, int life, const char* face, Screen* screen)
		: GameObject(pos, life, face, screen), speed(0), resurrection(false)
	{
	}

	void randomPosition(int screenSize)
	{
		if (pos < -98) {
			pos = rand() % screenSize;
			if (pos == 0)
				pos++;
			else if (pos > (screenSize - strlen(face)))
				pos = pos - strlen(face);

			life = 5;
			resurrection=false;
		}
	}
	void offResurrection()
	{
			resurrection = false;
	}
	void onResurrection()
	{
			resurrection = true;
	}
	bool getResurrectionMode()
	{
		return resurrection;
	}
	void move(int playerPos,int screenSize)
	{
		speed++;
		if (pos < -98)return;
		if (speed > 30) {
			if (pos < playerPos)
				pos = pos + 2;
			else if (pos > playerPos)
				pos = pos - 2;

			speed = 0;
		}
	}
	void rePosition(int screenSize, int faceSize)
	{
		if (pos<0 && pos>-6)
			pos = screenSize - faceSize;
		else if ((pos + faceSize) > screenSize)
			pos = 0;
	}
	void dead()
	{
		if (life > 0)return;
		else if (life <= 0)
		{
			pos = -100;
		}
	}
	void update(int bulletPos,int screenSize)
	{
		
		if (bulletPos >= pos && bulletPos <= pos + 3)
			lifeDown();
		dead();
	}
};

class Bullet : public GameObject {
protected:
	char info[20] = { NULL };
	char tempInfo[5] = { NULL };
	int infoLength;
	int tempInfoLength;
	bool isFiring;
	bool aim;
	bool gunMode;
	bool laserFiring;
	int laserPos;
	int cooltime;
	int lasertime;
	int laserHitTime;
public:
	Bullet() {
	};
	Bullet(int pos, int life, const char* face, Screen* screen)
		: GameObject(pos, life, face, screen), isFiring(false), aim(true)
		, gunMode(true), laserPos(0), cooltime(0), lasertime(31), laserHitTime(0),laserFiring(false)
	{
		tempInfoLength = 0;
		infoLength = 0;
	
	}
	void draw()
	{
		if (isFiring == false) return;
		GameObject::draw();
	}
	void drawInfomation(int playerPos, int playerFaceSize)
	{
		infoLength = 0;
		
		if (gunMode == false)
		{
			itoa(cooltime/15, tempInfo, 10);
			tempInfoLength = strlen(tempInfo);
			strcpy(info, tempInfo);
			info[tempInfoLength] = 's';
			infoLength += (tempInfoLength + 1);
			itoa(2 - (lasertime / 15), tempInfo, 10);
			tempInfoLength = strlen(tempInfo);
			strcpy(&info[infoLength], tempInfo);

			infoLength += tempInfoLength;
			info[infoLength] = 's';


			if (rightMode) {
				screen->draw(playerPos - strlen(info), info);
			}
			else if (rightMode == false) {
				screen->draw(playerPos + playerFaceSize, info);
			}

		}
	}

	void fire(int player_pos, int playerFaceSize)
	{
		aim = rightMode;
		if (rightMode == false)
			setPosition(player_pos - 1);
		else if (rightMode)
			setPosition(player_pos + playerFaceSize);
		if (gunMode == true) {
			isFiring = true;
		}
		else if (gunMode == false)
		{
			if (cooltime <= 0)
			{
				isFiring = true;
				laserFiring = true;
			}
			else if (cooltime > 0)
				return;

		}
	}
	bool getLaserFiring()
	{
		return laserFiring;
	}
	void gunModeChange()
	{
		isFiring = false;
		if (gunMode == false)
		{
			gunMode = true;
			return;
		}
		else if (gunMode == true)
			gunMode = false;
	}
	bool getGunMode()
	{
		return gunMode;
	}
	int getLaserTime()
	{
		return lasertime;
	}
	int getLaserCoolTime()
	{
		return cooltime;
	}
	int getLaserHitTime()
	{
		return  laserHitTime;
	}
	void setLaserCoolTime(int coolTime)
	{
		this->cooltime = coolTime;
	}
	void setLaserHitTime(int laserHitTime)
	{
		this->laserHitTime = laserHitTime;

	}
	void setLaserTime(int laserTime)
	{
		this->lasertime = laserTime;
	}
	
	void positionUpdate()
	{
		if (gunMode == true) {
			if (cooltime > 0)
				cooltime--;
			if (isFiring == false) return;
			int pos = getPosition();
			if (aim) {
				pos = pos + 2;
			}
			else if (aim == false) {
				pos = pos - 2;
			}
			setPosition(pos);
		}
	}
	
	void update(int enemy_pos, int enemyFaceSize, int player_pos, int playerFaceSize)
	{
		if (gunMode == true) {
			if (cooltime > 0)
				cooltime--;
			if (isFiring == false) return;
			int pos = getPosition();
			if ((pos >= enemy_pos && pos <= enemy_pos + 3) || pos == -1) {
				isFiring = false;
				pos = -5;
			}
			if (aim) {
				pos = pos + 2;
			}
			else if (aim == false) {
				pos = pos - 2;
			}
			setPosition(pos);
		}
		else if (gunMode == false)
		{
			if (isFiring == false)
			{
				if(cooltime>0)
				cooltime--;
				return;
			}
			else if (isFiring == true) {
				if (rightMode == false)
					setPosition(player_pos - 1);
				else if (rightMode)
					setPosition(player_pos + playerFaceSize);
				int pos = getPosition();
				laserPos = getPosition();
				if (rightMode) {
					if (enemy_pos > 0) {
						for (int i = 0; i < enemy_pos - pos; i++)
						{
							screen->draw(pos + i, "-");
							laserPos++;
							if (laserPos == enemy_pos - 1)
							{
								laserHitTime++;
							}
						}
					}
				}
				else if (rightMode == false) {
					if (enemy_pos > 0) {
						for (int i = 0; i < pos - enemy_pos - enemyFaceSize + 1; i++)
						{
							screen->draw(pos - i, "-");
							laserPos--;
							if (laserPos == enemy_pos + enemyFaceSize - 1)
							{
								laserHitTime++;
							}
						}
					}
				}
				if (laserHitTime >14)
				{
					setPosition(enemy_pos + 2);
					laserHitTime = 0;
				}
				lasertime--;
				if (lasertime  <=0)
				{
					laserFiring = false;
					isFiring = false;
					laserPos = 0;
					laserHitTime = 0;
					cooltime = 46;
					lasertime = 31;
				}

			}
		}
	}
	void laserUpdate(int enemy_pos, int enemyFaceSize, int player_pos, int playerFaceSize)
	{
		if (gunMode == false)
		{
		if (isFiring == false)
		{
			if (cooltime > 0)
				cooltime--;
			return;
		}
		else if (isFiring == true) {
			if (laserHitTime > 14)
			{
				laserHitTime = 0;
			}
			lasertime--;
			if (lasertime <= 0)
			{
				laserFiring = false;
				isFiring = false;
				laserPos = 0;
				laserHitTime = 0;
				cooltime = 46;
				lasertime = 31;
			}

		}
		}
	}


};

class magazine :public Bullet {
	int bullet;
	int reloadTime;
	bool shot;
	bool reloadMode;
	char info[20] = { NULL };
	char tempInfo[5] = { NULL };
	int infoLength;
	int tempInfoLength;
	Screen* screen;
public:
	magazine(Screen* screen):screen(screen) {
		reloadTime = 15;
		bullet = 10;
		shot = false;
		reloadMode = false;
		tempInfoLength = 0;
		infoLength = 0;
	}
	void fire()
	{
		if (bullet > 0)
			shot = true;

		reloadTime = 15;
	}
	int getMagazine()
	{
		return bullet;
	}
	void decreaseBullet()
	{
		bullet--;
	}
	void increaseBullet()
	{
		bullet++;
	}
	void reaload()
	{
		if (bullet == 0)
			reloadMode = true;
		if (shot == true)
			reloadMode = false;
	}
	void drawInfomation(bool playerMode,bool gunMode,int playerPos, int playerFaceSize)
	{
		infoLength = 0;
		memset(info, NULL, strlen(info));

		if (gunMode == true)
		{
			itoa(bullet, tempInfo, 10);
			tempInfoLength = strlen(tempInfo);
			strcpy(info, tempInfo);
			info[tempInfoLength] = 'n';
			infoLength += (tempInfoLength + 1);
		    if (reloadMode) {
				itoa(reloadTime, tempInfo, 10);
				tempInfoLength = strlen(tempInfo);
				strcpy(&info[infoLength], tempInfo);

				infoLength += tempInfoLength;
				info[infoLength] = 's';
				infoLength++;

				itoa((10-bullet), tempInfo, 10);
				tempInfoLength = strlen(tempInfo);
				strcpy(&info[infoLength], tempInfo);

				infoLength += tempInfoLength;
				info[infoLength] = 's';

			}

			if (playerMode) {
				screen->draw(playerPos - strlen(info), info);
			}
			else if (playerMode == false) {
				screen->draw(playerPos + playerFaceSize, info);
			}

		}
	}
	void update()
	{
		reaload();
		if (reloadMode) {
			reloadTime--;
			if (reloadTime == 0)
			{
				if (bullet < 10)
					increaseBullet();
				else 
					reloadMode=false;
				reloadTime = 15;
			}
		}
		if (shot)
		{
			decreaseBullet();
		}
		shot = false;
	}
	int getReloadTime()
	{
		return reloadTime;
	}


};
int rangeCheck(int enemyPos,int playerPos)
{
	if (enemyPos >= playerPos)
		return enemyPos - playerPos;
	else
		return playerPos - enemyPos;
}
int minRangeCheck(int range1, int range2, int range3, int range4, int range5)
{
	int minRange = 0;

	if (range1 <= range2)
		minRange = range1;
	else
		minRange = range2;

	if (minRange <= range3)
		minRange = minRange;
	else
		minRange = range3;

	if (minRange <= range4)
		minRange = minRange;
	else
		minRange = range4;

	if (minRange <= range5)
		minRange = minRange;
	else
		minRange = range5;


	return minRange;
}
int minRangeEnemyCheck(int range1, int range2, int range3, int range4, int range5,int minRange)
{
	if (range1 == minRange)
		return 0;
	if (range2 == minRange)
		return 1;
	if (range3 == minRange)
		return 2;
	if (range4 == minRange)
		return 3;
	if (range5 == minRange)
		return 4;
}
int shotEnemyRange(bool playerMode, int playerPos, int range1, int range2, int range3, int range4, int range5,int enemyPos1, int enemyPos2, int enemyPos3, int enemyPos4, int enemyPos5)
{
	int minRange = 0;
	if (playerMode == true)
	{
		if (enemyPos1 >= playerPos)
			minRange = range1;
		if (enemyPos2 >= playerPos)
		{
			if (range1 <= range2)
				minRange = range1;
			else
				minRange = range2;
		}
		if (enemyPos3 >= playerPos)
		{
			if (minRange <= range3)
				minRange = minRange;
			else
				minRange = range3;
		}
		if (enemyPos4 >= playerPos)
		{
			if (minRange <= range4)
				minRange = minRange;
			else
				minRange = range4;
		}
		if (enemyPos5 >= playerPos)
		{
			if (minRange <= range5)
				minRange = minRange;
			else
				minRange = range5;
		}
			return minRange;
	}
	else
	{
		if (enemyPos1 <= playerPos)
			minRange = range1;
		if (enemyPos2 <= playerPos)
		{
			if (range1 <= range2)
				minRange = range1;
			else
				minRange = range2;
		}
		if (enemyPos3 <= playerPos)
		{
			if (minRange <= range3)
				minRange = minRange;
			else
				minRange = range3;
		}
		if (enemyPos4 <= playerPos)
		{
			if (minRange <= range4)
				minRange = minRange;
			else
				minRange = range4;
		}
		if (enemyPos5 <= playerPos)
		{
			if (minRange <= range5)
				minRange = minRange;
			else
				minRange = range5;
		}
		return minRange;
	}

}
int shotRangeEnemyChect(int range1, int range2, int range3, int range4, int range5, int shotMinRange)
{
	if (shotMinRange == 0)
		return 5;
	if (range1 == shotMinRange)
		return 0;
	if (range2 == shotMinRange)
		return 1;
	if (range3 == shotMinRange)
		return 2;
	if (range4 == shotMinRange)
		return 3;
	if (range5 == shotMinRange)
		return 4;
}
void printInfomation(char* poison , int playerLife , int bullet , float playerCoolTime ,const char* poisonAttack, int enemyLife,int enemyLife2, int enemyLife3, int enemyLife4, int enemyLife5,float poisonTime , float poisonCoolTime)
{
	printf("\n\n\n player 중독 여부 : %s  HP : %d, 남은 총알 : %d 개 ,레이저 쿨타임: %.2f ,  \n",poison,playerLife,bullet,playerCoolTime);
	printf(" enemy 독 공격: %s   남은 독공격 시간: %.2f  독 공격 쿨타임 : %.2f\n", poisonAttack , poisonTime, poisonCoolTime);
	printf(" \t 1번적 HP :%d, 2번적 HP :%d, 3번적 HP :%d, 4번적 HP :%d, 5번적 HP :%d", enemyLife, enemyLife2, enemyLife3, enemyLife4, enemyLife5);
}
int main()
{
	Screen screen{ 90 };
	Player player{ 10,10,"^_^┌", &screen, "┐^_^" };
	Enemy *enemy[5];
	Bullet *bullet[11];
	magazine magazine{ &screen };
	int shotMinRange = 0;
	int shotMinRangeEnemy = 0;
	int minRange = 0;
	int minRangeEnemy = 0;
	int laserBullet=0;
	bool infoTimeSet=false;
	int infomationTime = 0;
	int playTime=0;
	int resurrectionTime = 0;
	for (int i = 0; i < 11; i++)
	{
		bullet[i] = new Bullet{ -5,1,"+",&screen };
	}
	for (int i = 0; i < 5; i++)
	{
		enemy[i] = new Enemy{ -100, 0, "(*-*)", &screen };
	}
	enemy[0]->setPosition(60);
	enemy[0]->setLife(5);




	while (true)
	{
		gotoxy(0, 0);
		screen.clear();
		playTime++;
		resurrectionTime++;

		if (_kbhit())
		{
			int c = _getch();
			switch (c) {
			case 'a':
				player.moveLeft();
				for (int i = 0; i < 11; i++)
				{
					bullet[i]->left();
				}

				break;
			case 'd':
				player.moveRight();
				for (int i = 0; i < 11; i++)
				{
					bullet[i]->right();
				}
				break;
			case'm':
				if (bullet[laserBullet]->getLaserFiring() == false)
				{
					for (int i = 0; i < 11; i++)
					{
						bullet[i]->gunModeChange();
					}
				}
				break;
			case ' ':
				if (bullet[magazine.getMagazine()]->getGunMode() == false)
				{
					laserBullet = magazine.getMagazine();
					bullet[magazine.getMagazine()]->fire(player.getPosition(), player.faceSize());
					if (bullet[laserBullet]->getLaserFiring() == true) {
						infoTimeSet = true;
					}
					break;
				}
				if (magazine.getMagazine() != 0)
				{
					bullet[magazine.getMagazine()]->fire(player.getPosition(), player.faceSize());
					if (bullet[magazine.getMagazine()]->getGunMode())
						magazine.fire();
					infoTimeSet = true;
				}
				break;
			}
		}
		if (infoTimeSet)
			infomationTime++;

		for (int i = 0; i < 5; i++)
		{
			enemy[i]->move(player.getPosition(), screen.length());
			enemy[i]->draw();
		}
		player.draw();
		for (int i = 0; i < 11; i++)
		{
			bullet[i]->draw();
		}

		// player와 enemy거리계산
		minRange = minRangeCheck(rangeCheck(enemy[0]->getPosition(), player.getPosition()), rangeCheck(enemy[1]->getPosition(), player.getPosition()), rangeCheck(enemy[2]->getPosition(), player.getPosition())
			, rangeCheck(enemy[3]->getPosition(), player.getPosition()), rangeCheck(enemy[4]->getPosition(), player.getPosition()));

		minRangeEnemy=minRangeEnemyCheck(rangeCheck(enemy[0]->getPosition(), player.getPosition()), rangeCheck(enemy[1]->getPosition(), player.getPosition()), rangeCheck(enemy[2]->getPosition(), player.getPosition())
			, rangeCheck(enemy[3]->getPosition(), player.getPosition()), rangeCheck(enemy[4]->getPosition(), player.getPosition()), minRange);
		shotMinRange = shotEnemyRange(player.getMode(), player.getPosition(), rangeCheck(enemy[0]->getPosition(), player.getPosition()), rangeCheck(enemy[1]->getPosition(),
			player.getPosition()), rangeCheck(enemy[2]->getPosition(), player.getPosition())
			, rangeCheck(enemy[3]->getPosition(), player.getPosition()), rangeCheck(enemy[4]->getPosition(), player.getPosition()),
			enemy[0]->getPosition(), enemy[1]->getPosition(), enemy[2]->getPosition(), enemy[3]->getPosition(), enemy[4]->getPosition());
		shotMinRangeEnemy = shotRangeEnemyChect(rangeCheck(enemy[0]->getPosition(), player.getPosition()), rangeCheck(enemy[1]->getPosition(), player.getPosition()), rangeCheck(enemy[2]->getPosition(), player.getPosition())
			, rangeCheck(enemy[3]->getPosition(), player.getPosition()), rangeCheck(enemy[4]->getPosition(), player.getPosition()), shotMinRange);

		//-------------------------------------------------------------------------------------------------------------------------------------------

		player.update(enemy[minRangeEnemy]->getPosition(),screen.length()-5,player.faceSize());
		for (int i = 0; i < 11; i++)
		{
			bullet[i]->setLaserCoolTime(bullet[laserBullet]->getLaserCoolTime());
			bullet[i]->setLaserTime(bullet[laserBullet]->getLaserTime());
			bullet[i]->setLaserHitTime(bullet[laserBullet]->getLaserHitTime());
			if (shotMinRangeEnemy != 5) {
			bullet[i]->update(enemy[shotMinRangeEnemy]->getPosition(), enemy[0]->faceSize(), player.getPosition(), player.faceSize());
				enemy[shotMinRangeEnemy]->update(bullet[i]->getPosition(), screen.length());
			}
			if (shotMinRangeEnemy == 5)
			{
				bullet[i]->laserUpdate(-100, enemy[0]->faceSize(), player.getPosition(), player.faceSize());
				bullet[i]->positionUpdate();
			}
		}

		//====================================================================================================================================================
		if (resurrectionTime > 150) {
			for (int i = 0; i < 5; i++)
			{
				enemy[i]->onResurrection();
			}
			for (int i = 0; i < 5 ; i++)
			{
				enemy[i]->randomPosition(screen.length() - 5);
				if (enemy[i]->getResurrectionMode() == false)
					break;
			}
			for (int i = 0; i < 5; i++)
			{
				enemy[i]->offResurrection();
			}
			resurrectionTime = 0;
		}
		magazine.update();
	

	if (infomationTime < 16 && infomationTime>0)
	{
		bullet[0]->drawInfomation(player.getPosition(), player.faceSize());
		magazine.drawInfomation(player.getMode(), bullet[0]->getGunMode(), player.getPosition(), player.faceSize());
	}
	else
	{
		infoTimeSet = false;
		infomationTime = 0;
	}


		screen.render();
		printInfomation(player.getPoison(), player.getLife(), magazine.getMagazine(), (float) bullet[laserBullet]->getLaserCoolTime()/15
			,player.poisonMode(),enemy[0]->getLife(), enemy[1]->getLife(), enemy[2]->getLife(), enemy[3]->getLife(), enemy[4]->getLife(), (float)player.getPoisonTime()/15, (float) player.getPoisonCoolTime()/15);
		if (player.getLife() == 0)
			break;
		Sleep(66);
	}

	system("cls");
	printf("생존시간 :%d초\n\n\n ", player.getPlayTime());
	system("pause");

	return 0;
}