#pragma once

class CMyShape {

public:
	float m_x;
	float m_y;
	CMyShape();
	CMyShape(float fx, float fy);
	virtual void draw();



};