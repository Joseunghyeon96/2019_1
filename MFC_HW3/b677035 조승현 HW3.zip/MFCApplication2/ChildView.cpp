﻿
// ChildView.cpp: CChildView 클래스의 구현
//

#include "stdafx.h"
#include "MFCApplication2.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
{
	num = 0;
	a = false;
	vectorX = 0;
	vectorY = 0;
	RB = false;
	LB = false;
	m_color = RGB(0, 0, 0);
	aniMode = false;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_Rect, &CChildView::OnRect)
	ON_UPDATE_COMMAND_UI(ID_Rect, &CChildView::OnUpdateRect)
	ON_COMMAND(ID_Cir, &CChildView::OnCir)
	ON_UPDATE_COMMAND_UI(ID_Cir, &CChildView::OnUpdateCir)
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_COMMAND(ID_COLOR_BLACK, &CChildView::OnColorBlack)
	ON_COMMAND(ID_COLOR_BLUE, &CChildView::OnColorBlue)
	ON_COMMAND(ID_COLOR_GREEN, &CChildView::OnColorGreen)
	ON_COMMAND(ID_COLOR_Red, &CChildView::OnColorRed)
	ON_UPDATE_COMMAND_UI(ID_COLOR_BLACK, &CChildView::OnUpdateColorBlack)
	ON_UPDATE_COMMAND_UI(ID_COLOR_BLUE, &CChildView::OnUpdateColorBlue)
	ON_UPDATE_COMMAND_UI(ID_COLOR_GREEN, &CChildView::OnUpdateColorGreen)
	ON_UPDATE_COMMAND_UI(ID_COLOR_Red, &CChildView::OnUpdateColorRed)
	ON_COMMAND(ID_Animation, &CChildView::OnAnimation)
	ON_UPDATE_COMMAND_UI(ID_Animation, &CChildView::OnUpdateAnimation)
	ON_WM_TIMER()
	ON_WM_CREATE()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()



// CChildView 메시지 처리기

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.
	
	CRect rect;
	GetClientRect(rect);

	CDC memDC; // 가상 DC
	memDC.CreateCompatibleDC(&dc);
	CBitmap bitmap;
	bitmap.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height()); 
	memDC.SelectObject(&bitmap);
	memDC.PatBlt(0, 0, rect.Width(), rect.Height(), WHITENESS);
	
	CBrush whiteBrush(RGB(255,255,255));
	CString str;
	POSITION pos = myPoint.GetHeadPosition();
	POSITION boolPos = myShape.GetHeadPosition();
	POSITION colorPos = myColor.GetHeadPosition();
	while (pos != NULL)
	{
		CPoint pt = myPoint.GetAt(pos);
		CBrush brush = myColor.GetAt(colorPos);
		memDC.SelectObject(&brush);
		if(myShape.GetAt(boolPos))
	    	memDC.Rectangle(pt.x-5, pt.y-5, pt.x + 5, pt.y + 5);
		else
		    memDC.Ellipse(pt.x - 5, pt.y - 5, pt.x + 5, pt.y + 5);
		myPoint.GetNext(pos);
		myColor.GetNext(colorPos);
		myShape.GetNext(boolPos);
	}

	memDC.SelectObject(&whiteBrush);
	memDC.Rectangle(start.x, start.y, end.x, end.y);
	str.Format(_T("점갯수: %d"), num);

	memDC.TextOut(1, 1,str);
	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &memDC, 0, 0, SRCCOPY);

	// 그리기 메시지에 대해서는 CWnd::OnPaint()를 호출하지 마십시오.
}



void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	LB = true;
	if (start.x < point.x && point.x < end.x && start.y < point.y && point.y < end.y)
	{
		return;
	}
	num++;
	myShape.AddTail(a);
	myPoint.AddTail(point);
	myColor.AddTail(m_color);
	Invalidate();
	CWnd::OnLButtonDown(nFlags, point);
}


void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	LB = false;
	CWnd::OnLButtonUp(nFlags, point);
}


void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (LB == true) {

		if (start.x < point.x && point.x <end.x && start.y < point.y && point.y <end.y)
		{
			return;
		}
		num++;
		myShape.AddTail(a);
		myPoint.AddTail(point);
		myColor.AddTail(m_color);
		Invalidate();
	}
	if (RB == true)
	{
		end = point;
		Invalidate();
	}
	CWnd::OnMouseMove(nFlags, point);
}


BOOL CChildView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	return false;
	//return CWnd::OnEraseBkgnd(pDC);
}


void CChildView::OnRect()
{
	a = true;
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
}


void CChildView::OnUpdateRect(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(a == true);
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
}


void CChildView::OnCir()
{

	a = false;
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
}


void CChildView::OnUpdateCir(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(a == false);
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
}


void CChildView::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	RB = true;
	start = point;
	end = point;
	Invalidate();
	CWnd::OnRButtonDown(nFlags, point);
}


void CChildView::OnRButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	end = point;
	RB = false;
	CPoint temp;

	if (end.x < start.x)
	{
		temp.x = end.x;
		end.x = start.x;
		start.x = temp.x;	
	}
	if (end.y < start.y)
	{
		temp.y = end.y;
		end.y = start.y;
		start.y = temp.y;
	}
	POSITION pos = myPoint.GetHeadPosition();
	POSITION boolPos = myShape.GetHeadPosition();
	POSITION colorPos = myColor.GetHeadPosition();
	while (pos != NULL)
	{
		POSITION cur = pos;
		POSITION boolCur = boolPos;
		POSITION colorCur = colorPos;
		CPoint pt = myPoint.GetAt(pos);
		myPoint.GetNext(pos);
		myShape.GetNext(boolPos);
		myColor.GetNext(colorPos);
		if (start.x < pt.x && pt.x < end.x && start.y < pt.y && pt.y < end.y)
		{
			myPoint.RemoveAt(cur);
			myShape.RemoveAt(boolCur);
			myColor.RemoveAt(colorCur);
			num--;
		}
	}
	Invalidate();

	CWnd::OnRButtonUp(nFlags, point);
}


void CChildView::OnColorBlack()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_color = RGB(0, 0, 0);
}


void CChildView::OnColorBlue()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_color = RGB(0, 0, 255);
}


void CChildView::OnColorGreen()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_color = RGB(0, 255, 0);
}


void CChildView::OnColorRed()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	m_color = RGB(255, 0, 0);
}


void CChildView::OnUpdateColorBlack(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(m_color==RGB(0,0,0));
}


void CChildView::OnUpdateColorBlue(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(m_color == RGB(0, 0, 255));
}


void CChildView::OnUpdateColorGreen(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(m_color == RGB(0, 255, 0));
}


void CChildView::OnUpdateColorRed(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(m_color == RGB(255, 0, 0));
}


void CChildView::OnAnimation()
{
	// TODO: 여기에 명령 처리기 코드를 추가합니다.
	if (aniMode)
		aniMode = false;
	else
		aniMode = true;
}


void CChildView::OnUpdateAnimation(CCmdUI *pCmdUI)
{
	// TODO: 여기에 명령 업데이트 UI 처리기 코드를 추가합니다.
	pCmdUI->SetCheck(aniMode);
}


void CChildView::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (nIDEvent == 0)
	{
		start.x += vectorX;
		start.y += vectorY;
		end.x += vectorX;
		end.y += vectorY;
		CRect rect;
		GetClientRect(rect);

		if (start.x < rect.left)
			vectorX = -vectorX;

		if (start.y < rect.top)
			vectorY = -vectorY;

		if (end.x > rect.right)
			vectorX = -vectorX;

		if (end.y > rect.Height())
			vectorY = -vectorY;


		POSITION pos = myPoint.GetHeadPosition();
		POSITION boolPos = myShape.GetHeadPosition();
		POSITION colorPos = myColor.GetHeadPosition();
		while (pos != NULL)
		{
			POSITION cur = pos;
			POSITION boolCur = boolPos;
			POSITION colorCur = colorPos;
			CPoint pt = myPoint.GetAt(pos);
			myPoint.GetNext(pos);
			myShape.GetNext(boolPos);
			myColor.GetNext(colorPos);
			if (start.x < pt.x && pt.x < end.x && start.y < pt.y && pt.y < end.y)
			{
				myPoint.RemoveAt(cur);
				myShape.RemoveAt(boolCur);
				myColor.RemoveAt(colorCur);
				num--;
			}
		}

		Invalidate();
	}


	CWnd::OnTimer(nIDEvent);
}


int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	SetTimer(0, 1, NULL);
	// TODO:  여기에 특수화된 작성 코드를 추가합니다.

	return 0;
}


void CChildView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (aniMode)
	{
		switch (nChar) {
		case VK_UP:
			vectorX = 0;
			vectorY = -5;
			break;
		case VK_DOWN:
			vectorX = 0;
			vectorY = 5;
			break;
		case VK_RIGHT:
			vectorX = 5;
			vectorY = 0;
			break;
		case VK_LEFT:
			vectorX = -5;
			vectorY = 0;
			break;
		}
	}

	Invalidate();
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}
